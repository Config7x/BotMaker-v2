'use strict';
module.exports = {
  handle: async ({ update, bot, api, db }) => {
    const msg = update.message;
    if (!msg) return;
    await api.sendMessage(msg.chat.id, 'hello from test template');
  }
};
